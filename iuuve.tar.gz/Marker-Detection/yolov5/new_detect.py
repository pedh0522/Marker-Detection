# Add these imports at the beginning of the script
import numpy as np
import cv2
import argparse
import csv
import os
import platform
import sys
from pathlib import Path

import torch

FILE = Path(__file__).resolve()
ROOT = FILE.parents[0]  # YOLOv5 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))  # add ROOT to PATH
ROOT = Path(os.path.relpath(ROOT, Path.cwd()))  # relative

from ultralytics.utils.plotting import Annotator, colors, save_one_box

from models.common import DetectMultiBackend
from utils.dataloaders import IMG_FORMATS, VID_FORMATS, LoadImages, LoadScreenshots, LoadStreams
from utils.general import (
    LOGGER,
    Profile,
    check_file,
    check_img_size,
    check_imshow,
    check_requirements,
    colorstr,
    cv2,
    increment_path,
    non_max_suppression,
    print_args,
    scale_boxes,
    strip_optimizer,
    xyxy2xywh,
)
from utils.torch_utils import select_device, smart_inference_mode

# Inside the 'run' function, add code to extract coordinates
def run(
    weights="/scratch/jankita.scee.iitmandi/yolo/yolov5/yolov5s.pt",
    source="/scratch/jankita.scee.iitmandi/yolo/datasets/yolo_data/images/val/point_movement_video_1_001_333.jpg",
    data="/scratch/jankita.scee.iitmandi/yolo/yolov5/data/new_data.yaml",
    imgsz=(640, 640),
    conf_thres=0.25,
    iou_thres=0.45,
    max_det=1000,
    device="",
    view_img=False,
    save_txt=False,
    save_csv=False,
    save_conf=False,
    save_crop=False,
    nosave=False,
    classes=None,
    agnostic_nms=False,
    augment=False,
    visualize=False,
    update=False,
    project=ROOT / "runs/detect",
    name="exp",
    exist_ok=False,
    line_thickness=3,
    hide_labels=False,
    hide_conf=False,
    half=False,
    dnn=False,
    vid_stride=1,
):
    # Initialization code remains the same
    
    coordinates = []  # List to store coordinates

    for path, im, im0s, vid_cap, s in dataset:
        # Inference and NMS code remains the same
        
        for i, det in enumerate(pred):
            if len(det):
                # Process detections and extract coordinates
                for *xyxy, conf, cls in reversed(det):
                    x_center = int((xyxy[0] + xyxy[2]) / 2)
                    y_center = int((xyxy[1] + xyxy[3]) / 2)
                    coordinates.append((x_center, y_center))

        # Display or save image code remains the same

    return coordinates

# In the main section, call run() and capture coordinates
if __name__ == "__main__":
    opt = parse_opt()
    coordinates = run(**vars(opt))
    print(coordinates)  # Print or use the coordinates as needed

import sys
import cv2
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import convolve2d
from PIL import Image  

print('Python version:', sys.version)
print('OpenCV version:', cv2.__version__)
print('NumPy version: ', np.__version__)

import torch

# Model (Choose a smaller variant for faster processing)
model = torch.hub.load("ultralytics/yolov5", "yolov5s")  # or yolov5n

# Images
img = "/scratch/jankita.scee.iitmandi/yolo/datasets/yolo_data/images/val/point_movement_video_100_10666.jpg"

# Inference
results = model(img)

# Feature tracking (assuming single object detection for simplicity)
if results.pandas().xyxy[0].shape[0] > 0:  # Check if any objects detected
    # Get first detected object (assuming you want to track one object)
    detection = results.pandas().xyxy[0].iloc[0]
  
    # Extract bounding box center coordinates (assuming format: x_min, y_min, x_max, y_max)
    center_x = int((detection["xmin"] + detection["xmax"]) / 2)
    center_y = int((detection["ymin"] + detection["ymax"]) / 2)
  
    # Print or use the center coordinates for tracking (e.g., store in a list for multiple frames)
    print(f"Center coordinates: ({center_x}, {center_y})")
else:
    print("No objects detected")

# Function for convolution

def linear_filter(img, kernel):
    print(img.shape)
    img_x, img_y = img.shape
    kernel_x, kernel_y = kernel.shape
    kernel_x = int(np.floor(kernel_x/2))
    kernel_y = int(np.floor(kernel_y/2))

    img_padded = np.pad(img, (kernel_x, kernel_y), 'constant', constant_values=0)
    X, Y = img_padded.shape

    conv_output = np.zeros((img_x, img_y))

    for i in range(kernel_x, X-kernel_x):
        for j in range(kernel_y, Y-kernel_y):
            window = img_padded[i-kernel_x:i+kernel_x+1, j-kernel_y:j+kernel_y+1]
            conv_output[i-kernel_x][j-kernel_y] = np.sum(window*kernel)

    return conv_output

def getNextPoints(im1, im2, xy, movedOutFlag):
    print("In function getNextPoints")

    xy2 = np.copy(xy).astype(float)
    im1 = im1.astype(np.float32)
    im2 = im2.astype(np.float32)

    # Gaussian kernel for smoothing
    kernel = np.array([
            [1, 4, 7, 4, 1],
            [4, 16, 26, 16, 4],
            [7, 26, 41, 26, 7],
            [4, 16, 26, 16, 4],
            [1, 4, 7, 4, 1,]], dtype=np.float32) / 273.0

    img = linear_filter(im1, kernel).astype(np.float32)
    Iy, Ix =  np.gradient(img)
    print((xy[0,0], xy[0,1]))
    # The given KLT algorithm is implemented
    for i in range(len(xy)):
        center = (int(xy[i, 0]), int(xy[i, 1]))
        print(np.shape(center))
        patch_x = cv2.getRectSubPix(Ix, (15,15), (int(xy2[i,0]), int(xy2[i,1])))
        patch_y = cv2.getRectSubPix(Iy, (15,15), (int(xy2[i,0]), int(xy2[i,1])))
        A = np.array([[np.sum(patch_x * patch_x), np.sum(patch_x * patch_y)], [np.sum(patch_x * patch_y), np.sum(patch_y * patch_y)]])

        for j in range(25):
            patch_t = cv2.getRectSubPix(im2, (15,15), (int(xy2[i,0]), int(xy2[i,1]))) - cv2.getRectSubPix(img, (15, 15), (int(xy[i,0]), int(xy[i,1])))
            B = -1* np.array([[np.sum(patch_x*patch_t)],[np.sum(patch_y*patch_t)]])
            disp = np.matmul(np.linalg.pinv(A), B)

            u = disp[0]
            v = disp[1]

            xy2[i, 0] = xy2[i, 0] + u
            xy2[i, 1] = xy2[i, 1] + v

            # Checking if the norm of (u, v) is leser than the threshold (from the textbook section - 9.1.3 Incremental refinement)
            if np.hypot(u, v) <= 0.01:
                break

    # Setting the movedOutFlag to 1 if the new pixels are out of bounds      
    if xy2[i,0] >= len(im1) or xy2[i,0] < 0 or xy2[i,1] >= len(im1[0]) or xy2[i,1] < 0:
        movedOutFlag[i] = 1

    return(xy2, movedOutFlag)

import cv2
import os

NUMBER_OF_FRAMES = 500  # Change this to the desired number of frames
VIDEO_PATH = "/scratch/jankita.scee.iitmandi/yolo/datasets/yolo_data/point_movement_video_1_001.mp4"  # Replace "your_video.mp4" with the path to your video
FRAMES_DIR = "/scratch/jankita.scee.iitmandi/yolo/yolov5/frames"  # Directory to save the frames
INTERVAL_MS = 166  # Interval in milliseconds

# Make directory to save frames if it doesn't exist
if not os.path.exists(FRAMES_DIR):
    os.makedirs(FRAMES_DIR)

def saveFramesFromVideo(video_path, frames_dir, interval_ms, num_frames):
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS)  # Get frames per second
    interval_frames = int(fps * (interval_ms / 1000.0))  # Calculate interval in terms of frames

    frame_count = 0
    saved_frame_count = 0

    while saved_frame_count < num_frames:
        ret, frame = cap.read()
        if not ret:
            break

        # Save frame at the specified interval
        if frame_count % interval_frames == 0:
            frame_path = os.path.join(frames_dir, f"frame_{saved_frame_count:05d}.png")
            cv2.imwrite(frame_path, frame)
            saved_frame_count += 1

        frame_count += 1

    cap.release()

    return saved_frame_count


DISPLAY_RADIUS = 3
GREEN = (0, 255, 0)
YELLOW = (0, 255, 255)

def readImages(frames_dir, num_frames):
    print("In function readImages")
    allImages = []
    allPaths = []
    for i in range(num_frames):
        print(f'reading image {i:05d}')
        image_path = os.path.join(frames_dir, f"frame_{i:05d}.png")
        imagetmp = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        allImages.append(imagetmp)
        allPaths.append(image_path)
    return allImages, allPaths


def getKeypoints(im0):
    # Assuming keypoint_detector function takes image path and returns keypoints
    results = model(im0)

    if results.pandas().xyxy[0].shape[0] > 0:  # Check if any objects detected
        # Get first detected object (assuming you want to track one object)
        detection = results.pandas().xyxy[0].iloc[0]
        
        # Extract bounding box center coordinates (assuming format: x_min, y_min, x_max, y_max)
        center_x = int((detection["xmin"] + detection["xmax"]) / 2)
        center_y = int((detection["ymin"] + detection["ymax"]) / 2)
    
        return np.asarray([[center_x, center_y]])
    
    else:
        print("No objects detected")


def trackPoints(xy, imageSequence):
    print("In function trackPoints")
    print(f'length of imageSequence = {len(imageSequence)}')
    movedOutFlag = np.zeros(xy.shape[0])
    xyt = []

    # Initialize velocities list to store velocities for each point at each frame
    velocities = []

    # Initialize prev_xy with initial positions
    prev_xy = xy.copy()

    for t in range(0, len(imageSequence) - 1):  # predict for all images except first in sequence
        print(f't = {t}; predicting for t = {t + 1}') 
        xy2, movedOutFlag = getNextPoints(imageSequence[t], imageSequence[t + 1], xy, movedOutFlag)

        frame_velocities = []

        for i in range(len(xy)):
            # Calculate displacement between current and previous position
            displacement = np.linalg.norm(xy2[i] - prev_xy[i])

            # Calculate time difference between frames (assuming constant frame rate)
            time_diff = 1 / 30  # Change this if your frame rate is different

            # Calculate velocity as displacement / time
            velocity = displacement / time_diff

            frame_velocities.append(velocity)

        # Add velocities for current frame to the velocities list
        velocities.append(frame_velocities)

        # Update previous positions after calculations
        prev_xy = xy.copy()
        xy = xy2

        for pt in xy2:
            xyt.append(pt)

        # for selected instants in time, display the latest image with highlighted keypoints 
        if t in [0, 10, 20, 30, 40, 49]:
            im2color = cv2.cvtColor(imageSequence[t + 1], cv2.COLOR_GRAY2BGR)
            corners = np.intp(np.round(xy2))

            for c in range(0, corners.shape[0]):
                x = corners[c][0]
                y = corners[c][1]
                cv2.circle(im2color, (x, y), DISPLAY_RADIUS, GREEN)

    return xyt, velocities

def drawPaths(im0color, xyt):
    print("In function drawPaths")

    # Create a VideoWriter object
    out = cv2.VideoWriter('tracked_keypoints.avi', cv2.VideoWriter_fourcc(*'DIVX'), 30, (im0color.shape[1], im0color.shape[0]))

    # Iterate through each point in the trajectory
    for pt in xyt:
        # Draw the point on the image
        im0color = cv2.circle(im0color, (round(pt[0]), round(pt[1])), radius=0, color=YELLOW, thickness=1)

        # Write the frame with the drawn point to the video
        out.write(im0color)

    # Release the VideoWriter object
    out.release()



def mainFunction():
    print("In mainFunction")
    num_frames_saved = saveFramesFromVideo(VIDEO_PATH, FRAMES_DIR, INTERVAL_MS, 100)
    print(f"Number of frames saved: {num_frames_saved}")
    allImgs, allPaths = readImages(FRAMES_DIR, num_frames_saved)
    print(f'number of images that were read = {len(allImgs)}')

    image0 = allPaths[0]
    xy = getKeypoints(image0)
    print("THIS IS IT", xy[0,0], xy[0,1])
    if xy is None:
        print("no points to track!")
        return
    print(f'number of detected keypoints = {xy.shape[0]}')

    image0 = cv2.imread(image0, cv2.IMREAD_GRAYSCALE)
    # display keypoints for image 0
    image0color = cv2.cvtColor(image0, cv2.COLOR_GRAY2BGR)
    corners = np.intp(np.round(xy))   
    for i in corners:
        x, y = i.ravel()
        cv2.circle(image0color, (x, y), DISPLAY_RADIUS, GREEN)

    # track the initial keypoints through all remaining images
    xyt, velocities = trackPoints(xy, allImgs)

    # Save trajectories and velocities to files
    np.savetxt('tracked_keypoints_trajectory.txt', xyt)
    np.savetxt('tracked_keypoints_velocities.txt', velocities)

    # in image 0, draw the paths taken by the keypoints 
    drawPaths(image0color, xyt)
    return



# Call the main function
mainFunction()

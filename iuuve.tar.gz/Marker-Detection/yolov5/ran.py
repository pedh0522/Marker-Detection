import cv2
print(cv2.__version__)

print(cv2.getBuildInformation())
import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt
import os

# Function to load YOLO detection results
def load_yolo_detections(txt_path):
    detections = []
    with open(txt_path, 'r') as file:
        for line in file.readlines():
            line = line.strip().split()
            class_id, conf, x_center, y_center, width, height = map(float, line)
            detections.append((class_id, conf, x_center, y_center, width, height))
    return detections

# Function to get center points from YOLO detections
def get_center_points(detections, frame_shape):
    h, w = frame_shape
    centers = []
    for detection in detections:
        _, _, x_center, y_center, width, height = detection
        x_center *= w
        y_center *= h
        centers.append((x_center, y_center))
    return np.array(centers, dtype=np.float32)

# KLT parameters
lk_params = dict(winSize=(15, 15),
                 maxLevel=5,
                 criteria=(cv.TERM_CRITERIA_EPS | cv.TERM_CRITERIA_COUNT, 10, 0.03),
                 minEigThreshold=1e-4)

# Shi-Tomasi corner detector parameters
feature_params = dict(maxCorners=400,
                      qualityLevel=0.01,
                      minDistance=7,
                      blockSize=7)

# Video capture
cap = cv.VideoCapture('C:\\aa\\visual_odometry\\project\\L_shaped_path.avi')

# Read the first frame
ret, frame = cap.read()
gray_frame = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)

# Load YOLO detections from the first frame
detections = load_yolo_detections('runs/detect/exp/labels/frame000001.txt')
# Assuming we are interested in the first detected object for tracking
centers = get_center_points(detections, frame.shape[:2])
if len(centers) > 0:
    obj_center = centers[0].reshape(-1, 1, 2)

    # Initialize the points for tracking
    p0 = cv.goodFeaturesToTrack(gray_frame, mask=None, **feature_params)
    p0 = np.concatenate((p0, obj_center.reshape(-1, 1, 2)), axis=0)

    prev_gray = gray_frame.copy()

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        gray_frame = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)

        # Track the features
        p1, p0 = track_features(prev_gray, gray_frame, p0)

        # Draw the tracks
        for i, (new, old) in enumerate(zip(p1, p0)):
            a, b = new.ravel()
            c, d = old.ravel()
            frame = cv.circle(frame, (a, b), 5, (0, 255, 0), -1)
            frame = cv.line(frame, (a, b), (c, d), (0, 255, 0), 2)

        # Display the frame with tracking
        cv.imshow('Frame', frame)

        # Break the loop
        if cv.waitKey(30) & 0xFF == ord('q'):
            break

        prev_gray = gray_frame.copy()
        p0 = p1.reshape(-1, 1, 2)

    cap.release()
    cv.destroyAllWindows()
else:
    print("No objects detected for tracking")
